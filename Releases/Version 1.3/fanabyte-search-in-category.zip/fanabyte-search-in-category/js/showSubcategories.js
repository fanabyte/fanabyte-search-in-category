jQuery(document).ready(function(){
	fanabyteSearchInCategory.showSubcategories = true;
});